{
  "summary": "No working Codeberg credentials found. SSH to git@codeberg.org fails with 'Permission denied (publickey)' (auth failure — the local ed25519 key is not registered on Codeberg; network and host-key are fine). No HTTPS credentials, no tea CLI, no CODEBERG/GITEA env tokens. Git identity is still the template placeholder.",
  "files": [
    {
      "path": "~/.ssh/id_ed25519.pub",
      "description": "Only SSH key on the machine (ed25519, comment 'user@user-host'). Offered to codeberg.org but rejected — not registered on the account."
    },
    {
      "path": "~/.ssh/config",
      "description": "Does not exist — no codeberg-specific host/identity config; ssh uses the default id_ed25519."
    },
    {
      "path": "~/.ssh/known_hosts",
      "description": "No codeberg.org entry (checked known_hosts and known_hosts.old) — this key has never successfully talked to Codeberg before."
    },
    {
      "path": "~/.gitconfig",
      "description": "Global git config: user.name='Your New Name', user.email='your_email@example.com' (template placeholders). Credential helpers: cache + git-credential-manager (secretservice store); GitHub-specific gh helper. No codeberg.org entry anywhere."
    },
    {
      "path": "~/.git-credentials",
      "description": "Does not exist — no stored HTTPS credentials for any host."
    },
    {
      "path": "~/.bashrc",
      "description": "Only GOOGLE_API_KEY exported; no CODEBERG_TOKEN / GITEA_TOKEN / GITEA_ACCESS_TOKEN. Same for ~/.profile, ~/.bash_profile, ~/.bash_login."
    },
    {
      "path": "~/.config/tea/",
      "description": "Does not exist. tea binary also absent from ~/.local/bin and /usr/bin (only unrelated gitea2john). tea CLI is not installed."
    }
  ],
  "architecture": "Read-only discovery of credential surfaces: ~/.ssh (one ed25519 keypair, no config, no codeberg in known_hosts), git config (~/.gitconfig, no ~/.git-credentials, no ~/.netrc), tea CLI (~/.local/bin, /usr/bin, ~/.config/tea, ~/.local/state/tea, ~/.tea — all absent), shell rc files for env tokens (none), plus a live SSH probe via the ssh:// scheme which reached codeberg.org and was rejected at publickey auth.",
  "report": "**Q1 — SSH auth to Codeberg: FAILS (publickey auth rejection).**\nProbe `ssh://git@codeberg.org/` returned: `git@codeberg.org: Permission denied (publickey).`\n- Failure mode: **authentication failure** — connection and host-key handling succeeded, but the offered key was rejected. Not a network or host-key problem.\n- Likely cause: `~/.ssh/id_ed25519.pub` (key comment `user@user-host`) is **not registered** in the alosslessdev Codeberg account. Corroborating evidence: `codeberg` appears nowhere in `~/.ssh/known_hosts` or `known_hosts.old`, so this key has never completed a session with Codeberg.\n- `~/.ssh/config` does not exist; no per-host identity configured. The only key pair on the machine is id_ed25519.\n- No `ssh -T` banner (\"Hi alosslessdev!\") was obtainable — auth never succeeded.\n\n**Q2 — HTTPS credentials: none found.** `~/.git-credentials` does not exist; `~/.netrc` does not exist. `git config --global credential.helper` = `cache` then `git-credential-manager` with `credentialStore = secretservice`. There is no `credential \"https://codeberg.org\"` section in `~/.gitconfig`. A codeberg entry *could* theoretically live in the system keyring via GCM, but nothing on disk indicates one; unverifiable read-only without prompting.\n\n**Q3 — tea CLI: not installed.** `tea` absent from `~/.local/bin/` and `/usr/bin/`; no `~/.config/tea/`, `~/.local/state/tea/`, or `~/.tea/`. (`gitea2john` in /usr/bin is an unrelated password-cracking tool.)\n\n**Q4 — Environment tokens: none found.** No CODEBERG_TOKEN / GITEA_TOKEN / GITEA_ACCESS_TOKEN in `~/.bashrc`, `~/.profile`, `~/.bash_profile`, `~/.bash_login`. Only token-like export in shell rc is GOOGLE_API_KEY.\n\n**Q5 — Git identity:** `user.name` = `Your New Name`, `user.email` = `your_email@example.com` — still the git-init template placeholders; must be set before pushing.\n\n**Conclusion: none of the methods is viable right now — no working credential exists. Viable path: register the existing `~/.ssh/id_ed25519.pub` key under the alosslessdev Codeberg account (Settings → SSH Keys), then SSH works; repo creation must then happen via the Codeberg web UI or a Forgejo API token (neither an API token nor tea is present). Alternatively, generate a Codeberg access token and use HTTPS."
}